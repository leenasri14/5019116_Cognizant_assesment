DECLARE
    CURSOR balance_cursor IS
        SELECT customer_id, balance
        FROM customers
        WHERE balance > 10000;
    v_customer_id customers.customer_id%TYPE;
BEGIN
    OPEN balance_cursor;
    LOOP
        FETCH balance_cursor INTO v_customer_id;
        EXIT WHEN balance_cursor%NOTFOUND;
        
        -- Update the IsVIP flag
        UPDATE customers
        SET IsVIP = 'TRUE'
        WHERE customer_id = v_customer_id;
    END LOOP;
    CLOSE balance_cursor;
    
    -- Commit the transaction
    COMMIT;
END;
/
