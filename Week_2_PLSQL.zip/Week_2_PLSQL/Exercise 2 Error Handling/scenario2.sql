CREATE OR REPLACE PROCEDURE UpdateSalary (
    p_employee_id IN NUMBER,
    p_percentage IN NUMBER
) IS
    employee_not_found EXCEPTION;
    v_salary NUMBER;
BEGIN
    -- Fetch current salary
    BEGIN
        SELECT salary INTO v_salary FROM employees WHERE employee_id = p_employee_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE employee_not_found;
    END;

    -- Update salary
    v_salary := v_salary * (1 + p_percentage / 100);
    UPDATE employees SET salary = v_salary WHERE employee_id = p_employee_id;

    -- Commit the transaction
    COMMIT;

EXCEPTION
    WHEN employee_not_found THEN
        
        DBMS_OUTPUT.PUT_LINE('Error: Employee ID ' || p_employee_id || ' not found');
        ROLLBACK;
    WHEN OTHERS THEN
        
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END;
/
