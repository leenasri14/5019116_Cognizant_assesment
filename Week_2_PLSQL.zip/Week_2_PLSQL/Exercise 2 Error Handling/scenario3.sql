CREATE OR REPLACE PROCEDURE AddNewCustomer (
    p_customer_id IN NUMBER,
    p_name IN VARCHAR2,
    p_address IN VARCHAR2
) IS
    duplicate_customer EXCEPTION;
BEGIN
    -- Check for duplicate customer ID
    DECLARE
        v_count NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_count FROM customers WHERE customer_id = p_customer_id;
        IF v_count > 0 THEN
            RAISE duplicate_customer;
        END IF;
    END;

    -- Insert new customer
    INSERT INTO customers (customer_id, name, address)
    VALUES (p_customer_id, p_name, p_address);

    -- Commit the transaction
    COMMIT;

EXCEPTION
    WHEN duplicate_customer THEN
        -- Log duplicate customer error
        DBMS_OUTPUT.PUT_LINE('Error: Customer ID ' || p_customer_id || ' already exists');
        ROLLBACK;
    WHEN OTHERS THEN
        -- Log any other errors
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END;
/
