DECLARE
    CURSOR cur_transactions IS
        SELECT customer_id, transaction_id, amount, transaction_date
        FROM Transactions
        WHERE EXTRACT(MONTH FROM transaction_date) = EXTRACT(MONTH FROM SYSDATE)
          AND EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM SYSDATE);
    
    v_customer_id Customers.customer_id%TYPE;
    v_transaction_id Transactions.transaction_id%TYPE;
    v_amount Transactions.amount%TYPE;
    v_transaction_date Transactions.transaction_date%TYPE;
BEGIN
    OPEN cur_transactions;
    
    LOOP
        FETCH cur_transactions INTO v_customer_id, v_transaction_id, v_amount, v_transaction_date;
        EXIT WHEN cur_transactions%NOTFOUND;
        
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || v_customer_id || 
                             ' | Transaction ID: ' || v_transaction_id
