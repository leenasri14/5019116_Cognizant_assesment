DECLARE
    CURSOR cur_loans IS
        SELECT loan_id, interest_rate FROM Loans;
    
    v_loan_id Loans.loan_id%TYPE;
    v_interest_rate Loans.interest_rate%TYPE;
    c_new_rate CONSTANT NUMBER := 5;  -- Example new interest rate
BEGIN
    OPEN cur_loans;
    
    LOOP
        FETCH cur_loans INTO v_loan_id, v_interest_rate;
        EXIT WHEN cur_loans%NOTFOUND;
        
        v_interest_rate := c_new_rate;
        
        UPDATE Loans
        SET interest_rate = v_interest_rate
        WHERE loan_id = v_loan_id;
    END LOOP;
    
    CLOSE cur_loans;
    
    COMMIT;
END;
/
