CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest IS
    CURSOR savings_cursor IS
        SELECT account_id, balance
        FROM accounts
        WHERE account_type = 'SAVINGS';
    v_account_id accounts.account_id%TYPE;
    v_balance accounts.balance%TYPE;
BEGIN
    OPEN savings_cursor;
    LOOP
        FETCH savings_cursor INTO v_account_id, v_balance;
        EXIT WHEN savings_cursor%NOTFOUND;
        
        -- Calculate new balance with 1% interest
        v_balance := v_balance * 1.01;
        
        -- Update the account balance
        UPDATE accounts
        SET balance = v_balance
        WHERE account_id = v_account_id;
    END LOOP;
    CLOSE savings_cursor;
    
    -- Commit the transaction
    COMMIT;
END;
/
