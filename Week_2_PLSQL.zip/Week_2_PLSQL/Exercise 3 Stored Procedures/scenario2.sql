CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus (
    p_department_id IN NUMBER,
    p_bonus_percentage IN NUMBER
) IS
    CURSOR employee_cursor IS
        SELECT employee_id, salary
        FROM employees
        WHERE department_id = p_department_id;
    v_employee_id employees.employee_id%TYPE;
    v_salary employees.salary%TYPE;
BEGIN
    OPEN employee_cursor;
    LOOP
        FETCH employee_cursor INTO v_employee_id, v_salary;
        EXIT WHEN employee_cursor%NOTFOUND;
        
        -- Calculate new salary with bonus percentage
        v_salary := v_salary * (1 + p_bonus_percentage / 100);
        
        -- Update the employee's salary
        UPDATE employees
        SET salary = v_salary
        WHERE employee_id = v_employee_id;
    END LOOP;
    CLOSE employee_cursor;
    
    -- Commit the transaction
    COMMIT;
END;
/
