CREATE OR REPLACE FUNCTION CalculateAge(p_dob DATE) RETURN NUMBER IS
    v_age NUMBER;
BEGIN
    v_age := EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM p_dob);
    
    IF TO_DATE(TO_CHAR(p_dob, 'MMDD'), 'MMDD') > TO_DATE(TO_CHAR(SYSDATE, 'MMDD'), 'MMDD') THEN
        v_age := v_age - 1;
    END IF;
    
    RETURN v_age;
END;
/
