CREATE OR REPLACE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (TransactionID, TransactionType, Amount, Timestamp)
    VALUES (:NEW.TransactionID, :NEW.TransactionType, :NEW.Amount, SYSDATE);
END;
/
