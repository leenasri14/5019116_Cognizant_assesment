package com.example.employeemanagementsystem.repository;

import com.example.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Find employees by department name
    List<Employee> findByDepartmentName(String departmentName);

    // Find employees by email
    Employee findByEmail(String email);

    // Find employees whose name contains a specific string
    List<Employee> findByNameContaining(String name);

    // Find all employees and sort them by name
    List<Employee> findAllByOrderByNameAsc();


   // Custom query to find employees by department name using @Query
    @Query("SELECT e FROM Employee e WHERE e.department.name = :departmentName")
    List<Employee> findEmployeesByDepartmentName(@Param("departmentName") String departmentName);

    // Custom query to find employees with salary greater than a specified amount
    @Query("SELECT e FROM Employee e WHERE e.salary > :salary")
    List<Employee> findEmployeesWithSalaryGreaterThan(@Param("salary") double salary);
}
