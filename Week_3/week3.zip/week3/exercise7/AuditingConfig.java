package com.example.employeemanagement.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.config.EnableJpaAuditing;

@Configuration
@EnableJpaAuditing
public class AuditingConfig {
}
