package com.example.employeemanagement.config;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AuditorAwareImpl implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        // Replace with actual logic to get the current user's username
        return Optional.of("system"); // Placeholder for current user
    }
}
