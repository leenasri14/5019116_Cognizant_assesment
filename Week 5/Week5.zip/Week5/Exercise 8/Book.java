import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Version;
import java.math.BigDecimal;

@Entity
public class Book {
    @Id
    private Long id;
    private String title;
    private String author;
    private BigDecimal price;
    private String isbn;

    @Version
    private Long version; // This field is used for optimistic locking

    // Getters and Setters
}
