import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private CustomerMapper customerMapper;

    public CustomerDTO createCustomer(CustomerDTO customerDTO) {
        Customer customer = customerMapper.customerDTOToCustomer(customerDTO);
        Customer savedCustomer = customerRepository.save(customer);
        return customerMapper.customerToCustomerDTO(savedCustomer);
    }

    public CustomerDTO getCustomerById(Long id) {
        return customerRepository.findById(id)
            .map(customerMapper::customerToCustomerDTO)
            .orElse(null);
    }

    public List<CustomerDTO> getAllCustomers() {
        return customerRepository.findAll().stream()
            .map(customerMapper::customerToCustomerDTO)
            .toList();
    }

    public CustomerDTO updateCustomer(Long id, CustomerDTO customerDTO) {
        return customerRepository.findById(id)
            .map(existingCustomer -> {
                existingCustomer.setName(customerDTO.getName());
                existingCustomer.setEmail(customerDTO.getEmail());
                try {
                    Customer updatedCustomer = customerRepository.save(existingCustomer);
                    return customerMapper.customerToCustomerDTO(updatedCustomer);
                } catch (OptimisticLockingFailureException e) {
                    // Handle optimistic locking failure
                    throw new RuntimeException("Update failed due to concurrent modification");
                }
            }).orElse(null);
    }

    public boolean deleteCustomer(Long id) {
        if (customerRepository.existsById(id)) {
            customerRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
