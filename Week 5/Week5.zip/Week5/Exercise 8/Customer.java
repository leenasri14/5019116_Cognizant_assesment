import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Version;

@Entity
public class Customer {
    @Id
    private Long id;
    private String name;
    private String email;

    @Version
    private Long version; // This field is used for optimistic locking

    // Getters and Setters
}
