import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;
    @Autowired
    private BookMapper bookMapper;

    public BookDTO createBook(BookDTO bookDTO) {
        Book book = bookMapper.bookDTOToBook(bookDTO);
        Book savedBook = bookRepository.save(book);
        return bookMapper.bookToBookDTO(savedBook);
    }

    public BookDTO getBookById(Long id) {
        return bookRepository.findById(id)
            .map(bookMapper::bookToBookDTO)
            .orElse(null);
    }

    public List<BookDTO> getAllBooks() {
        return bookRepository.findAll().stream()
            .map(bookMapper::bookToBookDTO)
            .toList();
    }

    public BookDTO updateBook(Long id, BookDTO bookDTO) {
        return bookRepository.findById(id)
            .map(existingBook -> {
                existingBook.setTitle(bookDTO.getTitle());
                existingBook.setAuthor(bookDTO.getAuthor());
                existingBook.setPrice(bookDTO.getPrice());
                existingBook.setIsbn(bookDTO.getIsbn());
                try {
                    Book updatedBook = bookRepository.save(existingBook);
                    return bookMapper.bookToBookDTO(updatedBook);
                } catch (OptimisticLockingFailureException e) {
                    // Handle optimistic locking failure
                    throw new RuntimeException("Update failed due to concurrent modification");
                }
            }).orElse(null);
    }

    public boolean deleteBook(Long id) {
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
