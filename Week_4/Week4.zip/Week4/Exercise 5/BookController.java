package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.model.Book;
import com.example.bookstoreapi.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    // POST /books - Create a new book
    @PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        Book createdBook = bookService.createBook(book);

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Location", "/books/" + createdBook.getId()); // Custom header indicating resource location

        return new ResponseEntity<>(createdBook, headers, HttpStatus.CREATED);
    }

    // GET /books/{id} - Fetch a book by its ID
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Book book = bookService.getBookById(id);
        if (book != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.add("X-Api-Version", "1.0"); // Custom header for API version

            return new ResponseEntity<>(book, headers, HttpStatus.OK);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); // Custom status code for not found
        }
    }

    // PUT /books/{id} - Update an existing book
    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book book) {
        Book updatedBook = bookService.updateBook(id, book);
        if (updatedBook != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.add("X-Api-Version", "1.0"); // Custom header for API version

            return new ResponseEntity<>(updatedBook, headers, HttpStatus.OK);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); // Custom status code for not found
        }
    }

    // DELETE /books/{id} - Delete a book by its ID
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) // Custom status code for successful deletion with no content
    public void deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
    }

    // GET /books - Retrieve all books
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookService.getAllBooks();

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Total-Count", String.valueOf(books.size())); // Custom header indicating the total number of books

        return new ResponseEntity<>(books, headers, HttpStatus.OK);
    }
}
