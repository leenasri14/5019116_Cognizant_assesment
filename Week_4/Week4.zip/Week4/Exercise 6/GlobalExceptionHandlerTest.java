import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
public class GlobalExceptionHandlerTest {

    private final MockMvc mockMvc;

    public GlobalExceptionHandlerTest(MockMvc mockMvc) {
        this.mockMvc = mockMvc;
    }

    @Test
    public void testHandleBookNotFoundException() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/books/9999") // Assumes an endpoint that might throw BookNotFoundException
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Book not found"));
    }

    @Test
    public void testHandleInvalidBookDataException() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"\", \"author\":\"\"}") // Example of invalid data
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Invalid book data"));
    }

    @Test
    public void testHandleGenericException() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/books/error") // Assumes an endpoint that throws a generic exception
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("An unexpected error occurred"));
    }
}
