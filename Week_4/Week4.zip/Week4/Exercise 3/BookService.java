package com.example.bookstoreapi.service;

import com.example.bookstoreapi.model.Book;

import java.util.List;

public interface BookService {
    // Existing methods...

    List<Book> getBooksByTitleAndAuthor(String title, String author);
}
