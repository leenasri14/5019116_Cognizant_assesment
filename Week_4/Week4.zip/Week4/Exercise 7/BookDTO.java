import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

public class BookDTO {
    private Long id;

    @JsonProperty("book_title")
    private String title;

    @JsonProperty("book_author")
    private String author;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "$#,.##")
    private BigDecimal price;

    private String isbn;

    // Getters and Setters
}
